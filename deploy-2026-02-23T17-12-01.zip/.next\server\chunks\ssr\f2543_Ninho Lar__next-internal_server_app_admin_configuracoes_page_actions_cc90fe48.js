module.exports=[814,(a,b,c)=>{}];

//# sourceMappingURL=f2543_Ninho%20Lar__next-internal_server_app_admin_configuracoes_page_actions_cc90fe48.js.map