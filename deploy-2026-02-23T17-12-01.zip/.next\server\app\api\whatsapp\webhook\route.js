var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/whatsapp/webhook/route.js")
R.c("server/chunks/[root-of-the-server]__75673e93._.js")
R.c("server/chunks/[root-of-the-server]__4aa007df._.js")
R.c("server/chunks/OneDrive_Documentos_Ninho Lar_src_lib_supabase_ts_00088d8b._.js")
R.c("server/chunks/[root-of-the-server]__5616d3d0._.js")
R.c("server/chunks/f2543_Ninho Lar__next-internal_server_app_api_whatsapp_webhook_route_actions_1d41f4d9.js")
R.m(37222)
module.exports=R.m(37222).exports
