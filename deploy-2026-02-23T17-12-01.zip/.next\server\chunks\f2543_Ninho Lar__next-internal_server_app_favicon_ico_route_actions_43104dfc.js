module.exports=[17927,(e,o,d)=>{}];

//# sourceMappingURL=f2543_Ninho%20Lar__next-internal_server_app_favicon_ico_route_actions_43104dfc.js.map