module.exports=[10101,(a,b,c)=>{}];

//# sourceMappingURL=f2543_Ninho%20Lar__next-internal_server_app_admin_relatorios_page_actions_958b06e9.js.map