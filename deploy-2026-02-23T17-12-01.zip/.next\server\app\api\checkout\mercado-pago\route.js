var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/checkout/mercado-pago/route.js")
R.c("server/chunks/[externals]__ac6eb0b1._.js")
R.c("server/chunks/259ce_aab4a87b._.js")
R.c("server/chunks/[root-of-the-server]__3dadff0a._.js")
R.c("server/chunks/[root-of-the-server]__5616d3d0._.js")
R.c("server/chunks/af7e2__next-internal_server_app_api_checkout_mercado-pago_route_actions_c67397f2.js")
R.m(27732)
module.exports=R.m(27732).exports
