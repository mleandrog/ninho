module.exports=[19101,(a,b,c)=>{}];

//# sourceMappingURL=f2543_Ninho%20Lar__next-internal_server_app_admin_produtos_page_actions_dd93af85.js.map