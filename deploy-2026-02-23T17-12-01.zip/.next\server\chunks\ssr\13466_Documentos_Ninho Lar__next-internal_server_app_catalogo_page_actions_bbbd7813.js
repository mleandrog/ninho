module.exports=[34071,(a,b,c)=>{}];

//# sourceMappingURL=13466_Documentos_Ninho%20Lar__next-internal_server_app_catalogo_page_actions_bbbd7813.js.map