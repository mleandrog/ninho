module.exports=[21128,(e,o,d)=>{}];

//# sourceMappingURL=f2543_Ninho%20Lar__next-internal_server_app_api_checkout_wa_route_actions_bb7eb4fd.js.map