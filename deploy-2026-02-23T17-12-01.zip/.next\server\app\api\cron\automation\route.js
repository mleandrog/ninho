var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/cron/automation/route.js")
R.c("server/chunks/[root-of-the-server]__9ade263c._.js")
R.c("server/chunks/OneDrive_Documentos_Ninho Lar_src_lib_supabase_ts_00088d8b._.js")
R.c("server/chunks/[root-of-the-server]__5616d3d0._.js")
R.c("server/chunks/f2543_Ninho Lar__next-internal_server_app_api_cron_automation_route_actions_28c7ae1d.js")
R.m(87479)
module.exports=R.m(87479).exports
