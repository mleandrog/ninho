module.exports=[63001,(e,o,d)=>{}];

//# sourceMappingURL=f2543_Ninho%20Lar__next-internal_server_app_api_whatsapp_groups_route_actions_c3d483f2.js.map