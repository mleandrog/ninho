module.exports=[85384,(a,b,c)=>{}];

//# sourceMappingURL=f2543_Ninho%20Lar__next-internal_server_app__global-error_page_actions_0a624b49.js.map