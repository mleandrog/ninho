var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/webhooks/whatsapp/route.js")
R.c("server/chunks/[root-of-the-server]__7409753d._.js")
R.c("server/chunks/[root-of-the-server]__4aa007df._.js")
R.c("server/chunks/OneDrive_Documentos_Ninho Lar_src_lib_supabase_ts_00088d8b._.js")
R.c("server/chunks/[root-of-the-server]__5616d3d0._.js")
R.c("server/chunks/af7e2__next-internal_server_app_api_webhooks_whatsapp_route_actions_b6a7e886.js")
R.m(54926)
module.exports=R.m(54926).exports
