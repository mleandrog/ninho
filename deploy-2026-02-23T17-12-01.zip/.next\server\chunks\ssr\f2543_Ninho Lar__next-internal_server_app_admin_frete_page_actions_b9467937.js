module.exports=[33628,(a,b,c)=>{}];

//# sourceMappingURL=f2543_Ninho%20Lar__next-internal_server_app_admin_frete_page_actions_b9467937.js.map