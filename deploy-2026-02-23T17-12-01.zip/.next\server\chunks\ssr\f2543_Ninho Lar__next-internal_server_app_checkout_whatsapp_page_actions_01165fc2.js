module.exports=[41477,(a,b,c)=>{}];

//# sourceMappingURL=f2543_Ninho%20Lar__next-internal_server_app_checkout_whatsapp_page_actions_01165fc2.js.map