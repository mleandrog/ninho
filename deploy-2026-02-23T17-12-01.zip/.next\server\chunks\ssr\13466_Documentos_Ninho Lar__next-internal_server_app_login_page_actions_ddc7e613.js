module.exports=[65785,(a,b,c)=>{}];

//# sourceMappingURL=13466_Documentos_Ninho%20Lar__next-internal_server_app_login_page_actions_ddc7e613.js.map