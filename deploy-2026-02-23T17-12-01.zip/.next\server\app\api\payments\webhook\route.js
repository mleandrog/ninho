var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/payments/webhook/route.js")
R.c("server/chunks/[root-of-the-server]__43028173._.js")
R.c("server/chunks/OneDrive_Documentos_Ninho Lar_src_lib_supabase_ts_00088d8b._.js")
R.c("server/chunks/[root-of-the-server]__5616d3d0._.js")
R.c("server/chunks/f2543_Ninho Lar__next-internal_server_app_api_payments_webhook_route_actions_594cfabd.js")
R.m(38101)
module.exports=R.m(38101).exports
