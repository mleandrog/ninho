module.exports=[99855,(a,b,c)=>{}];

//# sourceMappingURL=f2543_Ninho%20Lar__next-internal_server_app_admin_whatsapp_page_actions_03b38f24.js.map