var R=require("../../chunks/[turbopack]_runtime.js")("server/app/favicon.ico/route.js")
R.c("server/chunks/[externals]_next_dist_b01ab6e1._.js")
R.c("server/chunks/[root-of-the-server]__5616d3d0._.js")
R.c("server/chunks/259ce_next_dist_esm_build_templates_app-route_cc8512a4.js")
R.c("server/chunks/f2543_Ninho Lar__next-internal_server_app_favicon_ico_route_actions_43104dfc.js")
R.m(47786)
module.exports=R.m(47786).exports
