module.exports=[27101,(a,b,c)=>{}];

//# sourceMappingURL=OneDrive_Documentos_Ninho%20Lar__next-internal_server_app_page_actions_5cc5274a.js.map