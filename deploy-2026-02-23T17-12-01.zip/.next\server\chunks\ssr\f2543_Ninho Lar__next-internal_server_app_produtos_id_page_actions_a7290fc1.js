module.exports=[95537,(a,b,c)=>{}];

//# sourceMappingURL=f2543_Ninho%20Lar__next-internal_server_app_produtos_id_page_actions_a7290fc1.js.map