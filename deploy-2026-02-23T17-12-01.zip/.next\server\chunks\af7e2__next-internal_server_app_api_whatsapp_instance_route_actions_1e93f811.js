module.exports=[26136,(e,o,d)=>{}];

//# sourceMappingURL=af7e2__next-internal_server_app_api_whatsapp_instance_route_actions_1e93f811.js.map