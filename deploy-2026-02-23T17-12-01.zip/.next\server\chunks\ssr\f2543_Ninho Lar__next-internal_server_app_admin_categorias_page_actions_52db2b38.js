module.exports=[42135,(a,b,c)=>{}];

//# sourceMappingURL=f2543_Ninho%20Lar__next-internal_server_app_admin_categorias_page_actions_52db2b38.js.map