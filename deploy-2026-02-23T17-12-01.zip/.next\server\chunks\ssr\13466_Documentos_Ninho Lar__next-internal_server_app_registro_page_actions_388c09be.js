module.exports=[96913,(a,b,c)=>{}];

//# sourceMappingURL=13466_Documentos_Ninho%20Lar__next-internal_server_app_registro_page_actions_388c09be.js.map