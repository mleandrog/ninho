var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/whatsapp/instance/route.js")
R.c("server/chunks/[root-of-the-server]__8f2dc7ae._.js")
R.c("server/chunks/[root-of-the-server]__5616d3d0._.js")
R.c("server/chunks/af7e2__next-internal_server_app_api_whatsapp_instance_route_actions_1e93f811.js")
R.m(78489)
module.exports=R.m(78489).exports
