module.exports=[65689,(e,o,d)=>{}];

//# sourceMappingURL=f2543_Ninho%20Lar__next-internal_server_app_api_ai_chat_route_actions_c51de71c.js.map