var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/checkout/wa/route.js")
R.c("server/chunks/[root-of-the-server]__a08f9919._.js")
R.c("server/chunks/OneDrive_Documentos_Ninho Lar_src_lib_supabase_ts_00088d8b._.js")
R.c("server/chunks/[root-of-the-server]__5616d3d0._.js")
R.c("server/chunks/f2543_Ninho Lar__next-internal_server_app_api_checkout_wa_route_actions_bb7eb4fd.js")
R.m(59618)
module.exports=R.m(59618).exports
