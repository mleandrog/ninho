module.exports=[8445,(a,b,c)=>{}];

//# sourceMappingURL=f2543_Ninho%20Lar__next-internal_server_app_admin_pedidos_page_actions_dd3295aa.js.map