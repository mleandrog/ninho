module.exports=[66785,(a,b,c)=>{}];

//# sourceMappingURL=13466_Documentos_Ninho%20Lar__next-internal_server_app__not-found_page_actions_ba2224a2.js.map