var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/whatsapp/groups/route.js")
R.c("server/chunks/[root-of-the-server]__0b4f81e5._.js")
R.c("server/chunks/[root-of-the-server]__5616d3d0._.js")
R.c("server/chunks/f2543_Ninho Lar__next-internal_server_app_api_whatsapp_groups_route_actions_c3d483f2.js")
R.m(46691)
module.exports=R.m(46691).exports
