module.exports=[18949,(a,b,c)=>{}];

//# sourceMappingURL=13466_Documentos_Ninho%20Lar__next-internal_server_app_checkout_page_actions_eb268fe5.js.map