module.exports=[40879,a=>{a.v("/_next/static/media/favicon.0b3bf435.ico")},46098,a=>{"use strict";let b={src:a.i(40879).default,width:256,height:256};a.s(["default",0,b])}];

//# sourceMappingURL=OneDrive_Documentos_Ninho%20Lar_src_app_12f5486c._.js.map