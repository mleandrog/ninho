module.exports=[26753,(e,o,d)=>{}];

//# sourceMappingURL=f2543_Ninho%20Lar__next-internal_server_app_api_cron_automation_route_actions_28c7ae1d.js.map