module.exports=[4689,(a,b,c)=>{}];

//# sourceMappingURL=13466_Documentos_Ninho%20Lar__next-internal_server_app_admin_page_actions_3c8e4766.js.map