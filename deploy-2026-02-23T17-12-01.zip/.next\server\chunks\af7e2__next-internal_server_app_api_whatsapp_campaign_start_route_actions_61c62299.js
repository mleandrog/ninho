module.exports=[34828,(e,o,d)=>{}];

//# sourceMappingURL=af7e2__next-internal_server_app_api_whatsapp_campaign_start_route_actions_61c62299.js.map