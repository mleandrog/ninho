module.exports=[79730,(a,b,c)=>{}];

//# sourceMappingURL=af7e2__next-internal_server_app_admin_whatsapp_campanhas_%5Bid%5D_page_actions_ef43b718.js.map