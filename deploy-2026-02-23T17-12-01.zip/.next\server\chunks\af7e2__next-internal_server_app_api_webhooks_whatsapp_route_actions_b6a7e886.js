module.exports=[46522,(e,o,d)=>{}];

//# sourceMappingURL=af7e2__next-internal_server_app_api_webhooks_whatsapp_route_actions_b6a7e886.js.map