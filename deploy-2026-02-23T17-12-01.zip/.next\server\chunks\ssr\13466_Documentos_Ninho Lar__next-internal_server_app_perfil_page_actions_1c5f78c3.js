module.exports=[60501,(a,b,c)=>{}];

//# sourceMappingURL=13466_Documentos_Ninho%20Lar__next-internal_server_app_perfil_page_actions_1c5f78c3.js.map