module.exports=[76199,(a,b,c)=>{}];

//# sourceMappingURL=f2543_Ninho%20Lar__next-internal_server_app_admin_entregadores_page_actions_160db1c8.js.map